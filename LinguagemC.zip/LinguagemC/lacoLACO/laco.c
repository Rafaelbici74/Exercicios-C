#include <stdio.h>
#include <stdlib.h>

int main(){

    int i, j;

    for(i = 1; i <= 10; i++){

        for(j = 1; j <= i; j++){

            printf(" %d ", j);
            
        }
        putchar('\n'); //puchar fora do segundo LAÇO (for) para separar as linhas de numeros a cada repetição
    }

}